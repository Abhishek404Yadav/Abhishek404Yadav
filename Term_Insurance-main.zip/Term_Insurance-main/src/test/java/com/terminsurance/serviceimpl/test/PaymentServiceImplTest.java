package com.terminsurance.serviceimpl.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.terminsurance.dto.PaymentDTO;
import com.terminsurance.entity.Payment;
import com.terminsurance.entity.UserPolicy;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.PaymentRepository;
import com.terminsurance.serviceimpl.PaymentServiceImpl;

// Enable Mockito extension for JUnit 5
@ExtendWith(MockitoExtension.class)
class PaymentServiceImplTest {

	@Mock // Mocking PaymentRepository for testing
	private PaymentRepository paymentRepository;

	@Mock // Mocking ModelMapper for testing
	private ModelMapper modelMapper;

	@InjectMocks // Injecting mocks into PaymentServiceImpl for testing
	private PaymentServiceImpl paymentService;

	private Payment payment;
	private PaymentDTO paymentDTO;

	@BeforeEach
	// Set up common objects or states before each test
	void setUp() {
		payment = new Payment(1002, "teja@gmail.com", 1000.0, "netbanking", LocalDate.now(), "success",
				new UserPolicy());
		paymentDTO = new PaymentDTO();
	}

	@Test
	void testDuePaymentForUserPolicy() {
		when(modelMapper.map(any(Payment.class), eq(PaymentDTO.class))).thenReturn(paymentDTO);
		PaymentDTO result = paymentService.duePaymentForUserPolicy(payment);
		assertNotNull(result);
	}

	@Test
	public void testGetPaymentsByUserPolicyId() {
		int userPolicyId = 1;
		List<Payment> paymentList = Arrays.asList(new Payment(), new Payment());
		when(paymentRepository.findPaymentsByUserPolicyId(userPolicyId)).thenReturn(paymentList);
		when(modelMapper.map(any(), eq(PaymentDTO.class))).thenReturn(new PaymentDTO());
		List<PaymentDTO> result = paymentService.getPaymentsByUserPolicyId(userPolicyId);
		verify(modelMapper, times(paymentList.size())).map(any(), eq(PaymentDTO.class));
		assertNotNull(result);
	}

	@Test
	public void testGetPaymentsByUserPolicyIdNotFound() {
	    int userPolicyId = 1;
	    when(paymentRepository.findPaymentsByUserPolicyId(userPolicyId)).thenReturn(Arrays.asList());
	    assertThrows(NotFoundException.class, () -> paymentService.getPaymentsByUserPolicyId(userPolicyId));
	}

	@Test
	void testGetPaymentByPaymentId() {
		int paymentId = 1002;
		when(paymentRepository.findById(paymentId)).thenReturn(Optional.of(payment));
		when(modelMapper.map(any(Payment.class), eq(PaymentDTO.class))).thenReturn(paymentDTO);
		PaymentDTO result = paymentService.getPaymentByPaymentId(paymentId);
		assertNotNull(result);
	}

	@Test
	void testGetPaymentByPaymentIdNotFound() {
		int paymentId = 1002;
		when(paymentRepository.findById(paymentId)).thenReturn(Optional.empty());
		assertThrows(NotFoundException.class, () -> paymentService.getPaymentByPaymentId(paymentId));
	}
}
