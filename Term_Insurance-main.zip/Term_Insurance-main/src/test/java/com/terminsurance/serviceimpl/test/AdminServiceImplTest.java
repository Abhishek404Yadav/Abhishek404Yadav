package com.terminsurance.serviceimpl.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;

import org.mockito.junit.jupiter.MockitoExtension;

import com.terminsurance.dto.AdminDto;
import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.Admin;
import com.terminsurance.entity.User;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.AdminRepository;
import com.terminsurance.repository.UserRepository;
import com.terminsurance.serviceimpl.AdminServiceImpl;

@ExtendWith(MockitoExtension.class)
class AdminServiceImplTest {

    @Mock
    private AdminRepository adminRepo;
    @Mock
    private UserRepository userRepo;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AdminServiceImpl adminService;

    private Admin testAdmin;
    private Admin testAdminWithoutNumber;
    private User testUser;
    private User testUserWithoutNumber;

    @BeforeEach
    void setUp() {

        testAdmin = new Admin();
        testAdmin.setAdminEmail("admin@example.com");
        testAdmin.setAdminMobileNumber(1234567890);
        testAdmin.setAdminPassword("adminPass");

        testAdminWithoutNumber = new Admin();
        testAdminWithoutNumber.setAdminMobileNumber(1234567890);
        testAdminWithoutNumber.setAdminPassword("adminPass");

        testUser = new User();
        testUser.setUserEmail("user@example.com");
        testUser.setUserMobileNumber(98763210);

        testUserWithoutNumber = new User();
        testUserWithoutNumber.setUserMobileNumber(98763210);
    }

    @Test
    void testAddAdmin() {
       // when(modelMapper.map(any(), eq(Admin.class))).thenReturn(testAdmin);
        when(modelMapper.map(any(), eq(AdminDto.class))).thenReturn(new AdminDto());

        AdminDto result = adminService.addAdmin(testAdmin);

        assertNotNull(result);
        verify(adminRepo, times(1)).save(any());
    }

    @Test
    void testGetAllUser() {
        List<User> users = Arrays.asList(testUser);
        when(userRepo.findAll()).thenReturn(users);
        when(modelMapper.map(any(), eq(UserDto.class))).thenReturn(new UserDto());

        List<UserDto> result = adminService.getAllUser();

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void testSearchUserByEmail() {
        when(userRepo.findByUserEmail(anyString())).thenReturn(testUser);
        when(modelMapper.map(any(), eq(UserDto.class))).thenReturn(new UserDto());

        UserDto result = adminService.searchUser(testUser);

        assertNotNull(result);
    }

    @Test
    void testSearchUserByMobileNumber() {
        // Mocking the behavior of the userRepo and modelMapper
        when(userRepo.findByUserMobileNumber(anyLong())).thenReturn(testUser);
        when(modelMapper.map(any(), eq(UserDto.class))).thenReturn(new UserDto());
        UserDto result = adminService.searchUser(testUserWithoutNumber);
        assertNotNull(result);
    }

    @Test
    void testSearchUserNotFound() {
        assertThrows(NotFoundException.class, () -> adminService.searchUser(new User()));
    }

    @Test
    void testSignInWithEmail() {
        when(adminRepo.findByAdminEmail(anyString())).thenReturn(testAdmin);

        String result = adminService.signIn(testAdmin);

        assertEquals("SignIn Successfull", result);
    }

    @Test
    void testSignInWithMobileNumber() {
        when(adminRepo.findByAdminMobileNumber(anyLong())).thenReturn(testAdminWithoutNumber);

        String result = adminService.signIn(testAdminWithoutNumber);

        assertEquals("SignIn Successfull", result);
    }

    @Test
    void testSignInAdminNotFound() {
        assertThrows(NotFoundException.class, () -> adminService.signIn(new Admin()));
    }


}
