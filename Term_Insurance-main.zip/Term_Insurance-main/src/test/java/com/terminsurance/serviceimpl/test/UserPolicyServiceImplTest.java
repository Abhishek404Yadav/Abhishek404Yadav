package com.terminsurance.serviceimpl.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import com.terminsurance.dto.UserPolicyDto;
import com.terminsurance.entity.UserPolicy;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.UserPolicyRepository;
import com.terminsurance.serviceimpl.UserPolicyServiceImpl;

@ExtendWith(MockitoExtension.class)
class UserPolicyServiceImplTest {

	@Mock
	private UserPolicyRepository userPolicyRepository;

	@Mock
	private ModelMapper modelMapper;

	@InjectMocks
	private UserPolicyServiceImpl userPolicyService;

	private UserPolicy testUserPolicy;

	@BeforeEach
	// Initialize test data
	void setUp() {
		testUserPolicy = new UserPolicy();
		testUserPolicy.setUserPolicyId(1);
		testUserPolicy.setUserPremium(1000.0);
		testUserPolicy.setUserCoverAmount(50000.0);
		testUserPolicy.setUserPurchaseDate(LocalDate.now());
		testUserPolicy.setUserMaturityDate(LocalDate.now().plusYears(10));
		testUserPolicy.setUserPolicyTerm(10);
		testUserPolicy.setNomineeName("Test Nominee");
		testUserPolicy.setRelationship("Test Relationship");
		testUserPolicy.setNomineeDOB(LocalDate.of(1990, 1, 1));
	}

	@Test
	void saveUserPolicyTest() {
		when(modelMapper.map(testUserPolicy, UserPolicyDto.class)).thenReturn(new UserPolicyDto());
		UserPolicyDto result = userPolicyService.saveUserPolicy(testUserPolicy);
		assertNotNull(result);
	}

	@Test
	void getUserPolicyByIdTest() {
		when(userPolicyRepository.findById(anyInt())).thenReturn(Optional.of(testUserPolicy));
		when(modelMapper.map(testUserPolicy, UserPolicyDto.class)).thenReturn(new UserPolicyDto());

		UserPolicyDto result = userPolicyService.getUserPolicyById(1);

		assertNotNull(result);
	}

	@Test
	void getUserPolicyByUserIdTest() {
		when(userPolicyRepository.findUserPolicyByUserId(anyInt())).thenReturn(List.of(testUserPolicy));
		when(modelMapper.map(testUserPolicy, UserPolicyDto.class)).thenReturn(new UserPolicyDto());

		List<UserPolicyDto> result = userPolicyService.getUserPolicyByUserId(1);
		assertNotNull(result);
		assertFalse(result.isEmpty());
	}

	@Test
	void updateNomineeTest() {
		when(userPolicyRepository.findById(anyInt())).thenReturn(Optional.of(testUserPolicy));
		when(userPolicyRepository.save(any(UserPolicy.class))).thenReturn(testUserPolicy);
		when(modelMapper.map(testUserPolicy, UserPolicyDto.class)).thenReturn(new UserPolicyDto());
		UserPolicyDto result = userPolicyService.updateNominee(testUserPolicy);
		assertNotNull(result);
	}

	@Test
	void updateNomineeThrowsNotFoundExceptionTest() {
		when(userPolicyRepository.findById(anyInt())).thenReturn(Optional.empty());
		assertThrows(NotFoundException.class, () -> userPolicyService.updateNominee(testUserPolicy));
	}
}
