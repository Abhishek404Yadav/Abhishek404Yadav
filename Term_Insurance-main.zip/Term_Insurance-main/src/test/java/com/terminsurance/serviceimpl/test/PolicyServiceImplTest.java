package com.terminsurance.serviceimpl.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import com.terminsurance.dto.PolicyDto;
import com.terminsurance.entity.Policy;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.PolicyRepository;
import com.terminsurance.serviceimpl.PolicyServiceImpl;

class PolicyServiceImplTest {

	@Mock
	private PolicyRepository policyRepository;

	@Mock
	private ModelMapper modelMapper;

	@InjectMocks
	private PolicyServiceImpl policyService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testSavePolicy() {
		Policy policy = new Policy(1, "Test Policy", "Test Description");
		PolicyDto policyDto = new PolicyDto();
		when(modelMapper.map(policy, Policy.class)).thenReturn(policy);
		when(modelMapper.map(policy, PolicyDto.class)).thenReturn(policyDto);
		when(policyRepository.save(policy)).thenReturn(policy);

		PolicyDto savedPolicyDto = policyService.savePolicy(policy);

		assertEquals(policyDto, savedPolicyDto);
		verify(policyRepository).save(policy);
	}

	@Test
	void testGetAllPolicies() {
		List<Policy> policies = Arrays.asList(new Policy(1, "Policy1", "Desc1"), new Policy(2, "Policy2", "Desc2"));
		List<PolicyDto> policyDtos = Arrays.asList(new PolicyDto(), new PolicyDto());
		when(policyRepository.findAll()).thenReturn(policies);
		when(modelMapper.map(any(Policy.class), eq(PolicyDto.class))).thenReturn(new PolicyDto());

		List<PolicyDto> result = policyService.getAllPolicies();

		assertEquals(policyDtos.size(), result.size());
		verify(policyRepository).findAll();
	}

	@Test
	void testGetPolicyById() {
		Policy policy = new Policy(1, "Test Policy", "Test Description");
		PolicyDto policyDto = new PolicyDto();
		when(policyRepository.findById(1)).thenReturn(Optional.of(policy));
		when(modelMapper.map(policy, PolicyDto.class)).thenReturn(policyDto);

		PolicyDto result = policyService.getPolicyById(1);

		assertEquals(policyDto, result);
	}

	@Test
	void testGetPolicyByIdNotFound() {
		when(policyRepository.findById(1)).thenReturn(Optional.empty());

		assertThrows(NotFoundException.class, () -> policyService.getPolicyById(1));
	}

	@Test
	void testUpdatePolicyById() {
		Policy existingPolicy = new Policy(1, "Existing Policy", "Existing Description");
		Policy updatedPolicy = new Policy(1, "Updated Policy", "Updated Description");
		PolicyDto updatedPolicyDto = new PolicyDto();

		when(policyRepository.existsById(1)).thenReturn(true);
		when(policyRepository.findById(1)).thenReturn(Optional.of(existingPolicy));
		when(modelMapper.map(updatedPolicy, Policy.class)).thenReturn(updatedPolicy);
		when(modelMapper.map(updatedPolicy, PolicyDto.class)).thenReturn(updatedPolicyDto);
		when(policyRepository.save(updatedPolicy)).thenReturn(updatedPolicy);

		PolicyDto result = policyService.updatePolicyById(updatedPolicy);

		assertEquals(updatedPolicyDto, result);
		verify(policyRepository).save(updatedPolicy);
	}

	@Test
	void testUpdatePolicyByIdNotFound() {
		Policy nonExistingPolicy = new Policy(1, "Non-Existing Policy", "Non-Existing Description");

		when(policyRepository.existsById(1)).thenReturn(false);

		assertThrows(NotFoundException.class, () -> policyService.updatePolicyById(nonExistingPolicy));
	}
}
