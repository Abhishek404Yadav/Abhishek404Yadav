package com.terminsurance.serviceimpl.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import java.time.LocalDate;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.User;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.UserRepository;
import com.terminsurance.serviceimpl.UserServiceImpl;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private ModelMapper modelMapper;

	@InjectMocks
	private UserServiceImpl userService;

	private User user;

	private UserDto userDto;

	@BeforeEach
	// Initialize a test user
	void setUp() {
		user = new User();
		user.setUserId(1);
		user.setUserFirstName("Anil");
		user.setUserMiddleName("Ashok");
		user.setUserLastName("Horatti");
		user.setUserEmail("anil@gmail.com");
		user.setUserMobileNumber(9900112233L);
		user.setUserAadharCardNo(808011002211L);
		user.setUserPassword("aabbccdd");
		user.setUserDob(LocalDate.of(2000, 02, 20));
		user.setUserAge(23);


		// Initialize a test userDto
		userDto = new UserDto();
		userDto.setUserId(1);
		userDto.setUserFirstName("Anil");
		userDto.setUserMiddleName("Ashok");
		userDto.setUserLastName("Horatti");
		userDto.setUserEmail("anil@gmail.com");
		userDto.setUserMobileNumber(9900112233L);
		userDto.setUserAadharCardNo(808011002211L);
		userDto.setUserPassword("aabbccdd");
		userDto.setUserDob(LocalDate.of(2000, 02, 20));
		userDto.setUserAge(23);
	}

	@Test
	void testAddUser() {
		when(userRepository.save(any(User.class))).thenReturn(user);
		//when(modelMapper.map(any(), eq(User.class))).thenReturn(user);
		when(modelMapper.map(any(), eq(UserDto.class))).thenReturn(userDto);
		UserDto result = userService.addUser(user);
		assertNotNull(result);
		assertEquals(1, result.getUserId());
	}

	@Test
	void testGetUserById() {
		when(userRepository.findById(1)).thenReturn(Optional.of(user));
		when(modelMapper.map(user, UserDto.class)).thenReturn(userDto);
		UserDto result = userService.getUserById(1);
		assertNotNull(result);
		assertEquals(1, result.getUserId());
		assertEquals("Anil", result.getUserFirstName());
		assertEquals("Ashok", result.getUserMiddleName());
		assertEquals("Horatti", result.getUserLastName());
	}

	@Test
	void testGetUserByIdNotFound() {
		when(userRepository.findById(2)).thenReturn(Optional.empty());
		assertThrows(NotFoundException.class, () -> userService.getUserById(2));
	}

	@Test
	void testUpdateUser() {
		when(userRepository.existsById(1)).thenReturn(true);
		when(userRepository.save(any(User.class))).thenReturn(user);
		//when(modelMapper.map(any(), eq(User.class))).thenReturn(user);
		when(modelMapper.map(any(), eq(UserDto.class))).thenReturn(userDto);
		UserDto result = userService.updateUser(user);
		assertNotNull(result);
		assertEquals(1, result.getUserId());
	}

	@Test
	void testSignInSuccess() {
		when(userRepository.findByUserEmail("anil@gmail.com")).thenReturn(user);
		String result = userService.signIn("anil@gmail.com", "aabbccdd");
		assertEquals("SignIn Successfull", result);
	}

	@Test
	void testSignInInvalidCredentials() {
		when(userRepository.findByUserEmail("anil@gmail.com")).thenReturn(null);
		assertThrows(NotFoundException.class, () -> userService.signIn("anil@gmail.com", "abcdefg"));
	}

}
