package com.terminsurance.configuration;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
// defining and customizing the ModelMapper bean
public class ModelMapperConfiguration {
	@Bean
	// Indicates that the method returns a bean to be managed by the Spring container
	 ModelMapper modelMapper() {
		return new ModelMapper();

	}
}
