package com.terminsurance.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "admin")
public class Admin {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "adminId") // Column name in the table
    private int adminId;

    @NotBlank(message = "Name is mandatory") // name should not be null
    private String adminName;

    @NotBlank(message = "Email is mandatory")
    @Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,7}$", message = "Please provide a valid email address")
    private String adminEmail;

    @NotNull(message = "Mobile Number is mandatory")
    @Positive(message = "Mobile Number must be positive")
    private long adminMobileNumber;

    @NotBlank(message = "Password is mandatory")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String adminPassword;

    // !Default Constructors
    public Admin() {
    }

    // Parametrized Constructors
    public Admin(int adminId, @NotBlank(message = "FirstName is mandatory") String adminName,
            @NotBlank(message = "Email is mandatory") @Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,7}$", message = "Please provide a valid email address") String adminEmail,
            @NotNull(message = "Mobile Number is mandatory") @Positive(message = "Mobile Number must be positive") long adminMobileNumber,
            @NotBlank(message = "Password is mandatory") @Size(min = 6, message = "Password must be at least 6 characters") String adminPassword) {
        this.adminId = adminId;
        this.adminName = adminName;
        this.adminEmail = adminEmail;
        this.adminMobileNumber = adminMobileNumber;
        this.adminPassword = adminPassword;
    }

    // Getters and setters
    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public long getAdminMobileNumber() {
        return adminMobileNumber;
    }

    public void setAdminMobileNumber(long adminMobileNumber) {
        this.adminMobileNumber = adminMobileNumber;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    @Override
    public String toString() {
        return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", adminEmail=" + adminEmail
                + ", adminMobileNumber=" + adminMobileNumber + ", adminPassword=" + adminPassword + "]";
    }

}
