package com.terminsurance.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

@Entity // Represents a entity to be stored for the class in the database.
@Table(name = "payment") // specifies the name of the table in database
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) // auto generates the value
	private int paymentId;

	@NotBlank(message = "EmailID should not be null") // ensures the given string is not null
	@Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,7}$", message = "Please provide a valid email address")
	private String paymentEmailId;

	@Positive(message = "payment amount should be > 0")
	@Column(name = "premium") // annotation for giving column name in database
	private double paymentAmount;

	@NotBlank(message = "payment mode should not be null")
	private String paymentMode;

	private LocalDate paymentDate = LocalDate.now(); // it will return current date

	@NotBlank(message = "payment status should not be null")
	private String paymentStatus;

	@ManyToOne // annotation for achieving many to one relationship
	@JoinColumn(name = "userPolicyId") // annotation for adding foreign key column and to give name for that column in
										// database
	private UserPolicy userPolicy;

	// Default constructor
	public Payment() {

	}

	// parameterized constructor
	public Payment(int paymentId, String paymentEmailId, double paymentAmount, String paymentMode,
			LocalDate paymentDate,
			String paymentStatus, UserPolicy userPolicy) {
		super();
		this.paymentId = paymentId;
		this.paymentEmailId = paymentEmailId;
		this.paymentAmount = paymentAmount;
		this.paymentMode = paymentMode;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
		this.userPolicy = userPolicy;
	}

	// getters and setters for all data members
	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public String getPaymentEmailId() {
		return paymentEmailId;
	}

	public void setPaymentEmailId(String paymentEmailId) {
		this.paymentEmailId = paymentEmailId;
	}

	public double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public LocalDate getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public UserPolicy getUserPolicy() {
		return userPolicy;
	}

	public void setUserPolicy(UserPolicy userPolicy) {
		this.userPolicy = userPolicy;
	}

	// toString method
	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", paymentEmailId=" + paymentEmailId + ", paymentAmount="
				+ paymentAmount + ", paymentMode=" + paymentMode + ", paymentDate=" + paymentDate + ", paymentStatus="
				+ paymentStatus + ", userPolicy=" + userPolicy + "]";
	}

}