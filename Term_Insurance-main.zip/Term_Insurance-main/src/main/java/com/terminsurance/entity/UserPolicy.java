package com.terminsurance.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "userPolicy")
public class UserPolicy {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userPolicyId;
	@Min(value = 200, message = "UserPremium is mandatory")
	private double userPremium;
	@Min(value = 200000, message = "payment amount should be > 200000")
	private double userCoverAmount;
	private LocalDate userPurchaseDate = LocalDate.now();

	@NotNull(message = "Date should not be null")
	@Future(message = "Date Cannot be of Past")
	private LocalDate userMaturityDate;
	@Positive(message = "Policy term can not be null")
	private int userPolicyTerm;

	@NotBlank(message = "please provide nomineename")
	private String nomineeName;

	@NotBlank(message = "please provide nomineerelationship")
	private String relationship;
	@NotNull(message = "Date should not be null")
	private LocalDate nomineeDOB;

	@ManyToOne
	@JoinColumn(name = "policy_id")
	private Policy policy;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	public UserPolicy() {
		super();
	}

	public UserPolicy(int userPolicyId, double userPremium, double userCoverAmount, LocalDate userPurchaseDate,
			LocalDate userMaturityDate, int userPolicyTerm, String nomineeName, String relationship,
			LocalDate nomineeDOB, Policy policy, User user) {
		super();
		this.userPolicyId = userPolicyId;
		this.userPremium = userPremium;
		this.userCoverAmount = userCoverAmount;
		this.userPurchaseDate = userPurchaseDate;
		this.userMaturityDate = userMaturityDate;
		this.userPolicyTerm = userPolicyTerm;
		this.nomineeName = nomineeName;
		this.relationship = relationship;
		this.nomineeDOB = nomineeDOB;
		this.policy = policy;
		this.user = user;
	}

	public int getUserPolicyId() {
		return userPolicyId;
	}

	public void setUserPolicyId(int userPolicyId) {
		this.userPolicyId = userPolicyId;
	}

	public double getUserPremium() {
		return userPremium;
	}

	public void setUserPremium(double userPremium) {
		this.userPremium = userPremium;
	}

	public double getUserCoverAmount() {
		return userCoverAmount;
	}

	public void setUserCoverAmount(double userCoverAmount) {
		this.userCoverAmount = userCoverAmount;
	}

	public LocalDate getUserPurchaseDate() {
		return userPurchaseDate;
	}

	public void setUserPurchaseDate(LocalDate userPurchaseDate) {
		this.userPurchaseDate = userPurchaseDate;
	}

	public LocalDate getUserMaturityDate() {
		return userMaturityDate;
	}

	public void setUserMaturityDate(LocalDate userMaturityDate) {
		this.userMaturityDate = userMaturityDate;
	}

	public int getUserPolicyTerm() {
		return userPolicyTerm;
	}

	public void setUserPolicyTerm(int userPolicyTerm) {
		this.userPolicyTerm = userPolicyTerm;
	}

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public LocalDate getNomineeDOB() {
		return nomineeDOB;
	}

	public void setNomineeDOB(LocalDate nomineeDOB) {
		this.nomineeDOB = nomineeDOB;
	}

	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "UserPolicy [userPolicyId=" + userPolicyId + ", userPremium=" + userPremium + ", userCoverAmount="
				+ userCoverAmount + ", userPurchaseDate=" + userPurchaseDate + ", userMaturityDate=" + userMaturityDate
				+ ", userPolicyTerm=" + userPolicyTerm + ", nomineeName=" + nomineeName + ", relationship="
				+ relationship + ", nomineeDOB=" + nomineeDOB + ", policy=" + policy + ", user=" + user + "]";
	}

}
