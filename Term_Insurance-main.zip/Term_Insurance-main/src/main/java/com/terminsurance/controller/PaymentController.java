package com.terminsurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.terminsurance.dto.PaymentDTO;
import com.terminsurance.entity.Payment;
import com.terminsurance.serviceimpl.PaymentServiceImpl;

import jakarta.validation.Valid;

@RestController   // Indicates that this class is a Spring RestController
@RequestMapping("payment")   // Base URL mapping for all end points in this controller
public class PaymentController {
	
	@Autowired  // Injects an instance of PaymentServiceImpl automatically
	private PaymentServiceImpl paymentServiceImpl;

	// End point to handle due payment for a user's policy
	@PostMapping("/policy/duepayment")
	public PaymentDTO duePaymentForUserPolicy(@Valid @RequestBody Payment payment) {
		return paymentServiceImpl.duePaymentForUserPolicy(payment);
	}

	// End point to retrieve payments history for a user's policy by policy ID
	@GetMapping("/paymentshistory/policy/{userPolicyId}")
	public List<PaymentDTO> getPaymentsByUserPolicyId(@PathVariable int userPolicyId) {
		return paymentServiceImpl.getPaymentsByUserPolicyId(userPolicyId);
	}

	// End point to retrieve payment details by payment ID
	@GetMapping("/{paymentId}")
	public PaymentDTO getPaymentByPaymentId(@PathVariable int paymentId) {
		return paymentServiceImpl.getPaymentByPaymentId(paymentId);
	}
}