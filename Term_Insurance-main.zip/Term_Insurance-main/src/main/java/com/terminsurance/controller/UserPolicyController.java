package com.terminsurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.terminsurance.dto.UserPolicyDto;
import com.terminsurance.entity.UserPolicy;
import com.terminsurance.serviceimpl.UserPolicyServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("userpolicy")

public class UserPolicyController {
	@Autowired
	private UserPolicyServiceImpl userPolicyServiceImpl;

	// End point to buy policy
	@PostMapping("/buypolicy")
	public UserPolicyDto buyPolicy(@Valid @RequestBody UserPolicy userPolicy) {
		return userPolicyServiceImpl.saveUserPolicy(userPolicy);
	}

	// End point to get userpolicy by id
	@GetMapping("/policy/{id}")
	public UserPolicyDto getPolicy(@Valid @PathVariable Integer id) {
		return userPolicyServiceImpl.getUserPolicyById(id);
	}
	// End point to get list of policies by using user id

	@GetMapping("/policies/{userId}")
	public List<UserPolicyDto> getUserPolicyByUserId(@Valid @PathVariable int userId) {
		return userPolicyServiceImpl.getUserPolicyByUserId(userId);
	}

	// End point to update nominee details
	@PutMapping("/updatenominee")
	public UserPolicyDto updateNominee(@RequestBody UserPolicy userPolicy) {
		return userPolicyServiceImpl.updateNominee(userPolicy);
	}

}
