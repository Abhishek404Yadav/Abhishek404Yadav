package com.terminsurance.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.User;
import com.terminsurance.serviceimpl.UserServiceImpl;

import jakarta.validation.Valid;

// Controller class for handling user-related operations
@RestController

//Indicates that this controller should be validated
@Validated

//Base mapping for all end-points in this controller
@RequestMapping("user")

public class UserController {

	@Autowired
	// Inject UserRepository dependency for database operations
	private UserServiceImpl us;

	// Handling HTTP GET request
	// Register for user
	@PostMapping("/registeruser")
	public UserDto addUser(@Valid @RequestBody User user) {
		return us.addUser(user);
	}

	// Get User details by using userId
	@GetMapping("/getuser/{userId}")
	public UserDto getUserById(@Valid @PathVariable int userId) {
		return us.getUserById(userId);
	}

	// Update User by using userId
	@PutMapping("/updateuser")
	public UserDto updateUser(@Valid @RequestBody User user) {
		return us.updateUser(user);

	}

	// User SignIn using Email and Password
	@PostMapping("/signin")
	public String signIn(@RequestParam String userEmail, @RequestParam String userPassword) {
		return us.signIn(userEmail, userPassword);

	}

}
