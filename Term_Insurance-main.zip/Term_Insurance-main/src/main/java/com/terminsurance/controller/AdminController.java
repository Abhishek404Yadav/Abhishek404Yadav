package com.terminsurance.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.terminsurance.dto.AdminDto;
import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.Admin;
import com.terminsurance.entity.User;
import com.terminsurance.serviceimpl.AdminServiceImpl;
import jakarta.validation.Valid;

@RestController
@RequestMapping("admin")
public class AdminController {
    @Autowired // Inject AdminServiceImplemntation dependency
    private AdminServiceImpl adminServiceImpl;

    // Registering New Admin
    @PostMapping("/registeradmin")
    public AdminDto addAdmin(@Valid @RequestBody Admin admin) {
        return adminServiceImpl.addAdmin(admin);
    }

    // get all the user from the database
    @GetMapping("/alluser")
    public List<UserDto> getAllUser() {
        return adminServiceImpl.getAllUser();
    }

    // get user by email or phone no
    @PutMapping("/user/search")
    public UserDto searchUser(@RequestBody User user) {
        return adminServiceImpl.searchUser(user);
    }

    // sign in for Admin
    @PostMapping("/signin")
    public String signIn(@RequestBody Admin admin) {
        return adminServiceImpl.signIn(admin);

    }

}
