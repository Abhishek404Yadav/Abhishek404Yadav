package com.terminsurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.terminsurance.dto.PolicyDto;
import com.terminsurance.entity.Policy;
import com.terminsurance.serviceimpl.PolicyServiceImpl;

import jakarta.validation.Valid;
@RestController
@RequestMapping("policy")
public class PolicyController {
	@Autowired
private PolicyServiceImpl psi;
	 // End point to add a new policy
	 @PostMapping("addpolicy") 
	    public PolicyDto savePolicy(@Valid @RequestBody Policy policy) {
	        return psi.savePolicy(policy);
	    }
	 // End point to get all policies
	  @GetMapping("allpolicies")
	    public List<PolicyDto> getAllPolicies() {
	        return psi.getAllPolicies();
	    }
	//End point to get policy by id
	  @GetMapping("/{id}") 
	    public PolicyDto getPolicy(@PathVariable Integer id) {
	        return psi.getPolicyById(id);
	    }
	//End point to update policy using id
	    @PutMapping("/updatepolicy") 
	    public PolicyDto updatePolicyById(@Valid @RequestBody Policy policy) {
	    	return psi.updatePolicyById(policy);
	  }
}

