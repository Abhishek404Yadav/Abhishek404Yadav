package com.terminsurance.service;

import java.util.List;

import com.terminsurance.dto.PaymentDTO;
import com.terminsurance.entity.Payment;

//Service interface defining operations related to Payment
public interface PaymentService {
	
    public PaymentDTO duePaymentForUserPolicy(Payment payment);

    public List<PaymentDTO> getPaymentsByUserPolicyId(int userPolicyId);

    public PaymentDTO getPaymentByPaymentId(int paymentId);
    
}