package com.terminsurance.service;

import java.util.List;

import com.terminsurance.dto.UserPolicyDto;
import com.terminsurance.entity.UserPolicy;

public interface UserPolicyService {
	public UserPolicyDto saveUserPolicy(UserPolicy UserPolicy);

	public UserPolicyDto getUserPolicyById(Integer id);

	public List<UserPolicyDto> getUserPolicyByUserId(int userId);

	public UserPolicyDto updateNominee(UserPolicy userPolicy);
}
