package com.terminsurance.service;

import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.User;

//Service interface defining operations related to user
public interface UserService {
	public UserDto addUser(User user);

	public UserDto getUserById(int userId);

	public UserDto updateUser(User user);

	public String signIn(String userEmail, String userNumber);

}
