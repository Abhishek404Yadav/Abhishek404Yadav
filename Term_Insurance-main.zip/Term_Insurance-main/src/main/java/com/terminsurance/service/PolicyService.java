package com.terminsurance.service;

import java.util.List;

import com.terminsurance.dto.PolicyDto;
import com.terminsurance.entity.Policy;

public interface PolicyService {
	public PolicyDto savePolicy(Policy policy);

	public List<PolicyDto> getAllPolicies();

	public PolicyDto getPolicyById(Integer id);

	public PolicyDto updatePolicyById(Policy policy);
}