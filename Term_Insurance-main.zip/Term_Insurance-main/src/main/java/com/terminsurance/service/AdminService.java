package com.terminsurance.service;

import java.util.List;
import com.terminsurance.dto.AdminDto;
import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.Admin;
import com.terminsurance.entity.User;

public interface AdminService {
	public AdminDto addAdmin(Admin admin);

	public List<UserDto> getAllUser();

	public UserDto searchUser(User user);

	public String signIn(Admin admin);
}
