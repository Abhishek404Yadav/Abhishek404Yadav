package com.terminsurance.serviceimpl;

import java.time.LocalDate;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.terminsurance.dto.UserPolicyDto;
import com.terminsurance.entity.UserPolicy;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.UserPolicyRepository;
import com.terminsurance.service.UserPolicyService;

@Service
public class UserPolicyServiceImpl implements UserPolicyService {
	@Autowired
	private UserPolicyRepository userPolicyRepository;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	// save user policy details
	public UserPolicyDto saveUserPolicy(UserPolicy userPolicy) {
		userPolicyRepository.save(userPolicy);
		return modelMapper.map(userPolicy, UserPolicyDto.class);
	}

	@Override
	// finds whether the userpolicy id exists, if exists returns user or returns
	// exception
	public UserPolicyDto getUserPolicyById(Integer id) {
		return modelMapper.map(
				userPolicyRepository.findById(id).orElseThrow(() -> new NotFoundException("User policy not found")),
				UserPolicyDto.class);
	}

	@Override
	// To get the list of policies a user holds
	public List<UserPolicyDto> getUserPolicyByUserId(int userId) {
		if (userPolicyRepository.findUserPolicyByUserId(userId).isEmpty()) {
			throw new NotFoundException("No such user found");
		}
		List<UserPolicy> userPolicyList = userPolicyRepository.findUserPolicyByUserId(userId);
		return userPolicyList.stream().map(userPolicy -> modelMapper.map(userPolicy, UserPolicyDto.class)).toList();
	}

	@Override
	// To update nominee details
	public UserPolicyDto updateNominee(UserPolicy userPolicy) {
		int policyId = userPolicy.getUserPolicyId();
		String nomineeName = userPolicy.getNomineeName();
		String nomRelation = userPolicy.getRelationship();
		LocalDate dob = userPolicy.getNomineeDOB();

		UserPolicy userPolicyDb = userPolicyRepository.findById(policyId)
				.orElseThrow(() -> new NotFoundException("User policy not found"));
		userPolicyDb.setNomineeName(nomineeName);
		userPolicyDb.setRelationship(nomRelation);
		userPolicyDb.setNomineeDOB(dob);
		userPolicyRepository.save(userPolicyDb);
		return modelMapper.map(userPolicyDb, UserPolicyDto.class);
	}
}
