package com.terminsurance.serviceimpl;

import java.time.LocalDate;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.User;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.UserRepository;
import com.terminsurance.service.UserService;

@Service
// responsible for handling business logic related to user
public class UserServiceImpl implements UserService {

	@Autowired
	// Inject UserRepository dependency for performing database operations
	private UserRepository ur;

	@Autowired
	// annotation to inject the ModelMapper dependency for object mapping
	private ModelMapper modelMapper;

	@Override
	public UserDto addUser(User user) {
		// Calculate user age based on the current year and the user's birth year
		int age = LocalDate.now().getYear() - user.getUserDob().getYear();
		user.setUserAge(age);
		ur.save(user);
		return modelMapper.map(user, UserDto.class);
	}

	@Override
	public UserDto getUserById(int userId) {
		return ur.findById(userId).map(user -> modelMapper.map(user, UserDto.class))
				.orElseThrow(() -> new NotFoundException("UserId not found"));
	}

	@Override
	// Override method to update a user and return UserDto after checking and
	// handling existence of userId
	public UserDto updateUser(User user) {
		int userId = user.getUserId();
		int age = LocalDate.now().getYear() - user.getUserDob().getYear();
		user.setUserAge(age);

		// Check if user with the given ID exists in the database
		if (!ur.existsById(userId)) {
			throw new NotFoundException("UserId not found");
		} else {
			user.setUserId(userId);
		}
		ur.save(user);
		return modelMapper.map(user, UserDto.class);
	}

	@Override
	// user signIn method, checking and validating using email and password
	public String signIn(String userEmail, String userPassword) {
		User user = ur.findByUserEmail(userEmail);
		if (user != null && user.getUserPassword().equals(userPassword)) {
			return "SignIn Successfull";
		} else {
			throw new NotFoundException("Invalid credentials");
		}
	}
}
