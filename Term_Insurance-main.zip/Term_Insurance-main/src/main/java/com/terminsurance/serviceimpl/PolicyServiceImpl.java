package com.terminsurance.serviceimpl;

import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.terminsurance.dto.PolicyDto;
import com.terminsurance.entity.Policy;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.PolicyRepository;
import com.terminsurance.service.PolicyService;

@Service
public class PolicyServiceImpl implements PolicyService {
	@Autowired
	private PolicyRepository policyRepository;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	// Save a policy
	public PolicyDto savePolicy(Policy policy) {
		policyRepository.save(policy);
		return modelMapper.map(policy, PolicyDto.class);
	}

	@Override
	// To Find the List of all Policies
	public List<PolicyDto> getAllPolicies() {
		return policyRepository.findAll().stream()
				.map(policy -> modelMapper.map(policy, PolicyDto.class))
				.toList();
	}

	@Override
	// To find whether the policy exists with respective id
	public PolicyDto getPolicyById(Integer id) {
		return modelMapper
				.map(policyRepository.findById(id)
						.orElseThrow(() -> new NotFoundException("policy not found")),
						PolicyDto.class);
	}

	@Override
	// To update policy if policy exists
	public PolicyDto updatePolicyById(Policy policy) {
		int id = policy.getPolicyId();
		if (!policyRepository.existsById(id)) {
			throw new NotFoundException("policy Not Found");
		}
		policyRepository.save(policy);
		return modelMapper.map(policy, PolicyDto.class);
	}

}
