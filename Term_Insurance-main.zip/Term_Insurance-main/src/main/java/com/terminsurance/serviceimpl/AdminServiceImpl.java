package com.terminsurance.serviceimpl;

import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.terminsurance.dto.AdminDto;
import com.terminsurance.dto.UserDto;
import com.terminsurance.entity.Admin;
import com.terminsurance.entity.User;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.AdminRepository;
import com.terminsurance.repository.UserRepository;
import com.terminsurance.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    // Injecting AdminRepository dependency for database operations
    private AdminRepository adminRepo;
    @Autowired
    // Inject UserRepository dependency for database operations
    private UserRepository userRepo;
    @Autowired
    // Using ModelMapper for mapping objects with DTO
    private ModelMapper modelMapper;

    @Override
    // register for admin and saving in the database
    public AdminDto addAdmin(Admin requestBodyAdmin) {
        adminRepo.save(requestBodyAdmin);
        return modelMapper.map(requestBodyAdmin, AdminDto.class);
    }

    @Override
    // get all the User of user database
    public List<UserDto> getAllUser() {
        return userRepo.findAll().stream().map(user -> modelMapper.map(user, UserDto.class))
                .toList();
    }

    @Override
    // searching User based on user email or user phone no
    public UserDto searchUser(User requestBodyUser) {
        User dbUser = null;
        if (requestBodyUser.getUserEmail() != null) {
            dbUser = userRepo.findByUserEmail(requestBodyUser.getUserEmail());
        } else if (requestBodyUser.getUserMobileNumber() != 0) {
            dbUser = userRepo.findByUserMobileNumber(requestBodyUser.getUserMobileNumber());
        }
        if (dbUser == null) {
            throw new NotFoundException("User not found");
        } else {
            return modelMapper.map(dbUser, UserDto.class);
        }

    }

    @Override
    // login admin with email or phone no
    public String signIn(Admin requestBodyAdmin) {
        Admin dbAdmin = null;
        if (requestBodyAdmin.getAdminEmail() != null) {
            dbAdmin = adminRepo.findByAdminEmail(requestBodyAdmin.getAdminEmail());
        } else if (requestBodyAdmin.getAdminMobileNumber() != 0) {
            dbAdmin = adminRepo.findByAdminMobileNumber(requestBodyAdmin.getAdminMobileNumber());
        }
        String pass = requestBodyAdmin.getAdminPassword();
        if (dbAdmin == null) {
            throw new NotFoundException("Admin with this details not found");
        }
        if (!dbAdmin.getAdminPassword().equals(pass)) {
            throw new NotFoundException("Password incorrect");
        } else {
            return "SignIn Successfull";
        }
    }

}
