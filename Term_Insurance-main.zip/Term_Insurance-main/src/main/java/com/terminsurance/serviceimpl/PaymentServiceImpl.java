package com.terminsurance.serviceimpl;

import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.terminsurance.dto.PaymentDTO;
import com.terminsurance.entity.Payment;
import com.terminsurance.exception.NotFoundException;
import com.terminsurance.repository.PaymentRepository;
import com.terminsurance.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	// Injects an instance of PaymentRepository automatically
	private PaymentRepository paymentRepository;

	@Autowired
	// Injects an instance of ModelMapper automatically
	private ModelMapper modelMapper;

	@Override
	// Save payment details for a user's policy
	public PaymentDTO duePaymentForUserPolicy(Payment payment) {
		paymentRepository.save(payment);
		return modelMapper.map(payment, PaymentDTO.class);
	}

	@Override
	// Retrieve payments for a user's policy by policy ID
	public List<PaymentDTO> getPaymentsByUserPolicyId(int userPolicyId) {
		
		// Check if payments exist for the given user policy ID
		if (paymentRepository.findPaymentsByUserPolicyId(userPolicyId).isEmpty()) {
			throw new NotFoundException("payments not found for this user policy id");
		}
		List<Payment> paymentList = paymentRepository.findPaymentsByUserPolicyId(userPolicyId);
		return paymentList.stream()
				.map(payment -> modelMapper.map(payment, PaymentDTO.class))
				.toList();

	}

	@Override
	// Retrieve payment details by payment ID
	public PaymentDTO getPaymentByPaymentId(int paymentId) {
		return paymentRepository.findById(paymentId)
				.map(payment -> modelMapper.map(payment, PaymentDTO.class))
				.orElseThrow(() -> new NotFoundException("Payment not found for this paymnet id"));
	}
}
