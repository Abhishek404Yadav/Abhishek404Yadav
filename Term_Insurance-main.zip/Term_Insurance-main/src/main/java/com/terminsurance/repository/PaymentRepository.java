package com.terminsurance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.terminsurance.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {

	// Custom query to find payments by user policy ID using native SQL
	@Query(value = "SELECT * FROM payment p WHERE p.user_policy_id=:userPolicyId",
			nativeQuery = true)
	public List<Payment> findPaymentsByUserPolicyId(int userPolicyId);
	
}
