package com.terminsurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.terminsurance.entity.User;

@Repository
// It extends JpaRepository for User entities with Integer as the type of primary key
public interface UserRepository extends JpaRepository<User, Integer> {

	User findByUserEmail(String email);

	User findByUserMobileNumber(Long phoneNo);

}
