package com.terminsurance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.terminsurance.entity.UserPolicy;

@Repository
public interface UserPolicyRepository extends JpaRepository<UserPolicy, Integer> {
	@Query(value = "SELECT * FROM user_policy p WHERE p.user_id=:userId", nativeQuery = true)
	public List<UserPolicy> findUserPolicyByUserId(int userId);

}
