package com.terminsurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.terminsurance.entity.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
    // inbuilt method for fetching admin based on email and phone no
    Admin findByAdminEmail(String email);

    Admin findByAdminMobileNumber(long mobile);

}
