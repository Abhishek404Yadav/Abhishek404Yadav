package com.terminsurance.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

public class PaymentDTO {
	
	private int paymentId;
	
	@NotBlank(message = "EmailID should not be null")
	@Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,7}$", message = "Please provide a valid email address")
	private String paymentEmailId;
	
	@Positive(message = "payment amount should be > 0")
	private double paymentAmount;
	
	@NotBlank(message = "payment mode should not be null")
	private String paymentMode;
	
	private LocalDate paymentDate;
	
	@NotBlank(message = "payment status should not be null")
	private String paymentStatus;
	
	
	//default constructor
	public PaymentDTO() {
		
	}

	//parameterized constructor
	public PaymentDTO(int paymentId, String paymentEmailId, double paymentAmount, String paymentMode,
			LocalDate paymentDate,
			String paymentStatus) {
		super();
		this.paymentId = paymentId;
		this.paymentEmailId = paymentEmailId;
		this.paymentAmount = paymentAmount;
		this.paymentMode = paymentMode;
		this.paymentDate = paymentDate;
		this.paymentStatus = paymentStatus;
	}

	//getters and setters for data members
	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public String getPaymentEmailId() {
		return paymentEmailId;
	}

	public void setPaymentEmailId(String paymentEmailId) {
		this.paymentEmailId = paymentEmailId;
	}

	public double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public LocalDate getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	//to string method
	@Override
	public String toString() {
		return "PaymentDTO [paymentId=" + paymentId + ", paymentEmailId=" + paymentEmailId + ", paymentAmount="
				+ paymentAmount + ", paymentMode=" + paymentMode + ", paymentDate=" + paymentDate + ", paymentStatus="
				+ paymentStatus + "]";
	}
}