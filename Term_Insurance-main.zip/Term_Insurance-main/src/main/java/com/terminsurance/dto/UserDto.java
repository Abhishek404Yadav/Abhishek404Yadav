package com.terminsurance.dto;

import java.time.LocalDate;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

// UserDto class
public class UserDto {
	private int userId;

	@NotBlank(message = "First Name is mandatory") // First Name field with Validation
	private String userFirstName;

	private String userMiddleName;

	@NotBlank(message = "Last Name is mandatory")
	private String userLastName;

	@NotBlank(message = "Email is mandatory")
	@Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,7}$", message = "Please provide a valid email address")
	private String userEmail;

	@NotNull(message = "Mobile Number is mandatory")
	@Positive(message = "Mobile Number must be positive")
	private long userMobileNumber;

	@NotNull(message = "Aadhar Card Number is mandatory")
	@Positive(message = "Aadhar Card Number must be positive")
	private long userAadharCardNo;

	@NotBlank(message = "Password is mandatory")
	@Size(min = 6, message = "Password must be at least 6 characters")
	private String userPassword;

	@NotNull(message = "DOB is mandatory")
	@Past(message = "DOB must be in the past")
	private LocalDate userDob;

	private int userAge;

	public UserDto() {
	}

	// parameterized constructor
	public UserDto(int userId, String userFirstName, String userMiddleName, String userLastName,
			String userEmail, long userMobileNumber, long userAadharCardNo, String userPassword,
			LocalDate userDob, int userAge) {
		super();
		this.userId = userId;
		this.userFirstName = userFirstName;
		this.userMiddleName = userMiddleName;
		this.userLastName = userLastName;
		this.userEmail = userEmail;
		this.userMobileNumber = userMobileNumber;
		this.userAadharCardNo = userAadharCardNo;
		this.userPassword = userPassword;
		this.userDob = userDob;
		this.userAge = userAge;
	}

	// implements getter and setter for properties
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserMiddleName() {
		return userMiddleName;
	}

	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getUserMobileNumber() {
		return userMobileNumber;
	}

	public void setUserMobileNumber(long userMobileNumber) {
		this.userMobileNumber = userMobileNumber;
	}

	public long getUserAadharCardNo() {
		return userAadharCardNo;
	}

	public void setUserAadharCardNo(long userAadharCardNo) {
		this.userAadharCardNo = userAadharCardNo;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public LocalDate getUserDob() {
		return userDob;
	}

	public void setUserDob(LocalDate userDob) {
		this.userDob = userDob;
	}

	public int getUserAge() {
		return userAge;
	}

	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}

	@Override
	// Creating a string representation of the UserDto object
	public String toString() {
		return "UserDto [userId=" + userId + ", userFirstName=" + userFirstName
				+ ", userMiddleName=" + userMiddleName + ", userLastName=" + userLastName
				+ ", userEmail=" + userEmail + ", userMobileNumber=" + userMobileNumber
				+ ", userAadharCardNo=" + userAadharCardNo + ", userPassword=" + userPassword
				+ ", userDob=" + userDob + ", userAge=" + userAge + "]";
	}

}
