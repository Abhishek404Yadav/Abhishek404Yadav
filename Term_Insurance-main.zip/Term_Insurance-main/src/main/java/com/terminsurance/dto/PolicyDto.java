package com.terminsurance.dto;

import jakarta.validation.constraints.NotBlank;

public class PolicyDto {
	private int policyId;
	@NotBlank(message = "please provide policyname")
	private String policyName;
	@NotBlank(message = "policyDescription should not be null")
	private String policyDescription;

	public PolicyDto() {
		super();
	}

	public PolicyDto(int policyId, String policyName, String policyDescription) {
		super();
		this.policyId = policyId;
		this.policyName = policyName;
		this.policyDescription = policyDescription;
	}

	public int getPolicyId() {
		return policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public String getPolicyDescription() {
		return policyDescription;
	}

	public void setPolicyDescription(String policyDescription) {
		this.policyDescription = policyDescription;
	}

	@Override
	public String toString() {
		return "PolicyDTO [policyId=" + policyId + ", policyName=" + policyName + ", policyDescription="
				+ policyDescription + "]";
	}
}
