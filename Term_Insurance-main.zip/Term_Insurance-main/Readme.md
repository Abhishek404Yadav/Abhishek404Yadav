# Online Term Insurance Platform - README

## Overview

Welcome to the Online Term Insurance Platform, a microservices-based system for managing users, policies, user policies, payments, and administrative tasks. This platform is built using Spring Boot, follows the MVC architecture, and utilizes PostgreSQL as the database. The codebase includes comprehensive unit test cases to ensure robust functionality.

## Controllers

### User Controller

- **Update User:** `PUT /user/updateuser`
- **Sign In:** `POST /user/signin`
- **Register User:** `POST /user/registeruser`
- **Get User by ID:** `GET /user/getuser/{userId}`

### Policy Controller

- **Update Policy:** `PUT /policy/updatepolicy`
- **Add Policy:** `POST /policy/addpolicy`
- **Get Policy by ID:** `GET /policy/{id}`
- **Get All Policies:** `GET /policy/allpolicies`

### User Policy Controller

- **Update Nominee:** `POST /userpolicy/updatenominee`
- **Buy Policy:** `POST /userpolicy/buypolicy`
- **Get Policy by ID:** `GET /userpolicy/policy/{id}`
- **Get Policies by User ID:** `GET /userpolicy/policies/{userId}`

### Payment Controller

- **Due Payment for a Policy:** `POST /payment/policy/duepayment`
- **Get Payment by ID:** `GET /payment/{paymentId}`
- **Payment History for a User Policy:** `GET /payment/paymentshistory/policy/{userPolicyId}`

### Admin Controller

- **User Search:** `POST /admin/user/search`
- **Admin Sign In:** `POST /admin/signin`
- **Register Admin:** `POST /admin/registeradmin`
- **Get All Users:** `GET /admin/alluser`

## Schemas

- **User**
- **UserDto**
- **Policy**
- **PolicyDto**
- **UserPolicy**
- **UserPolicyDto**
- **Payment**
- **PaymentDTO**
- **Admin**
- **AdminDto**

These schemas define the data structures used across the platform, ensuring consistency and clarity in communication between different components.

## Technology Stack

- **Framework:** Spring Boot
- **Architecture:** MVC (Model-View-Controller)
- **Database:** PostgreSQL

## Testing

The platform includes a comprehensive suite of unit test cases to ensure the reliability and correctness of the implemented features. The tests cover various scenarios to validate the functionality of each component.

## Getting Started

To set up the platform locally, follow these steps:

1. Clone the repository.
2. Configure the PostgreSQL database.
3. Run the Spring Boot application.

Detailed instructions for setting up and running the platform can be found in the project's documentation.

Feel free to explore and contribute to the development of the Online Term Insurance Platform!
